import React, { useState } from 'react';
import {
  TrendingUp,
  DollarSign,
  Users,
  Repeat,
  Download,
  Calendar,
  Sparkles,
  ArrowUpRight,
  FileDown,
  Loader2,
  Check
} from 'lucide-react';
import { MONTHLY_GROWTH_PROJECTIONS } from '../data/proposalData';
import { GrowthMonth } from '../types/bullbee';
import { generateBrandedPdf } from '../utils/pdfExport';
import confetti from 'canvas-confetti';

export const GrowthProjectionsSection: React.FC = () => {
  const [scenario, setScenario] = useState<'conservative' | 'target' | 'aggressive'>('target');
  const [hoveredMonth, setHoveredMonth] = useState<GrowthMonth | null>(null);
  const [isDownloadingPdf, setIsDownloadingPdf] = useState<boolean>(false);
  const [pdfSuccess, setPdfSuccess] = useState<boolean>(false);

  // Scenario multipliers
  const multiplier = scenario === 'conservative' ? 0.78 : scenario === 'aggressive' ? 1.22 : 1.0;

  const adjustedData: GrowthMonth[] = MONTHLY_GROWTH_PROJECTIONS.map((m) => ({
    ...m,
    grossRevenue: Math.round(m.grossRevenue * multiplier),
    netRevenue: Math.round(m.netRevenue * multiplier),
    newCustomers: Math.round(m.newCustomers * multiplier),
    repeatCustomers: Math.round(m.repeatCustomers * multiplier),
    roas: Number(( (m.grossRevenue * multiplier) / m.spend ).toFixed(2)),
  }));

  const totalGrossRevenue = adjustedData.reduce((acc, curr) => acc + curr.grossRevenue, 0);
  const totalSpend = adjustedData.reduce((acc, curr) => acc + curr.spend, 0);
  const totalNewCustomers = adjustedData.reduce((acc, curr) => acc + curr.newCustomers, 0);
  const totalRepeatOrders = adjustedData.reduce((acc, curr) => acc + curr.repeatCustomers, 0);
  const blendedRoas = (totalGrossRevenue / totalSpend).toFixed(2);

  // SVG Chart Dimensions
  const chartHeight = 240;
  const chartWidth = 700;
  const maxRevenue = Math.max(...adjustedData.map((d) => d.grossRevenue));

  // Generate path points
  const points = adjustedData.map((d, index) => {
    const x = (index / (adjustedData.length - 1)) * (chartWidth - 60) + 30;
    const y = chartHeight - (d.grossRevenue / maxRevenue) * (chartHeight - 40) - 20;
    return { x, y, data: d };
  });

  const pathD = points.reduce((acc, p, i) => `${acc} ${i === 0 ? 'M' : 'L'} ${p.x} ${p.y}`, '');
  const areaD = `${pathD} L ${points[points.length - 1].x} ${chartHeight} L ${points[0].x} ${chartHeight} Z`;

  const handleExportSummary = () => {
    confetti({ particleCount: 60, spread: 60, origin: { y: 0.8 } });
    const content = `BULLBEE 12-MONTH PROJECTIONS SUMMARY (${scenario.toUpperCase()})\n` +
      `Total Gross Revenue: $${totalGrossRevenue.toLocaleString()}\n` +
      `Total Ad Spend: $${totalSpend.toLocaleString()}\n` +
      `Blended ROAS: ${blendedRoas}x\n` +
      `Total New Customers: ${totalNewCustomers.toLocaleString()}\n` +
      `Total Repeat Orders: ${totalRepeatOrders.toLocaleString()}\n` +
      `Month 12 Run Rate: $${adjustedData[11].grossRevenue.toLocaleString()}/mo\n`;

    const blob = new Blob([content], { type: 'text/plain;charset=utf-8' });
    const url = URL.createObjectURL(blob);
    const link = document.createElement('a');
    link.href = url;
    link.download = `bullbee-growth-model-${scenario}.txt`;
    link.click();
    URL.revokeObjectURL(url);
  };

  const handleDownloadPdfReport = async () => {
    try {
      setIsDownloadingPdf(true);
      setPdfSuccess(false);
      await generateBrandedPdf();
      setPdfSuccess(true);
      confetti({
        particleCount: 80,
        spread: 60,
        origin: { y: 0.7 },
        colors: ['#D3AF68', '#D9AD5B', '#D09931', '#F8F0E2'],
      });
      setTimeout(() => setPdfSuccess(false), 3500);
    } catch (e) {
      console.error('PDF export failed:', e);
    } finally {
      setIsDownloadingPdf(false);
    }
  };

  return (
    <section id="growth-projections" className="relative border-b border-stone-800 bg-[#141414] py-20 lg:py-28">
      <div className="mx-auto max-w-7xl px-6 sm:px-8 lg:px-12">
        {/* Section Header */}
        <div className="flex flex-col md:flex-row md:items-end justify-between gap-8 mb-14">
          <div>
            <div className="flex items-center gap-2.5 text-xs font-semibold uppercase tracking-widest text-[#D3AF68] font-display mb-3">
              <span>Section 05</span>
              <span aria-hidden="true" className="text-stone-600">·</span>
              <span>Financial Projections & User Growth Model</span>
            </div>
            <h2 className="font-display text-3xl sm:text-4xl lg:text-5xl font-bold tracking-tight text-[#F8F0E2] uppercase">
              12-Month Financial Roadmap
            </h2>
            <p className="mt-4 text-base text-stone-300 max-w-2xl font-body leading-relaxed">
              Detailed month-by-month financial projection scaling from $21,833/mo initial spend to $221.5k/mo run rate with a defensible 5.54x exit ROAS as replenishment cohorts compound.
            </p>
          </div>

          {/* Scenario Selector & Export Buttons with more breathing room */}
          <div className="flex flex-wrap items-center gap-3">
            <div className="flex p-1.5 bg-[#1a1a1a] rounded-xl border border-stone-800 text-xs">
              <button
                onClick={() => setScenario('conservative')}
                className={`px-3.5 py-2 rounded-lg transition-colors cursor-pointer ${
                  scenario === 'conservative'
                    ? 'bg-bullbee-gradient text-[#171717] font-bold shadow-sm'
                    : 'text-stone-400 hover:text-stone-200'
                }`}
              >
                Conservative
              </button>
              <button
                onClick={() => setScenario('target')}
                className={`px-3.5 py-2 rounded-lg transition-colors cursor-pointer ${
                  scenario === 'target'
                    ? 'bg-bullbee-gradient text-[#171717] font-bold shadow-sm'
                    : 'text-stone-400 hover:text-stone-200'
                }`}
              >
                Target Plan
              </button>
              <button
                onClick={() => setScenario('aggressive')}
                className={`px-3.5 py-2 rounded-lg transition-colors cursor-pointer ${
                  scenario === 'aggressive'
                    ? 'bg-bullbee-gradient text-[#171717] font-bold shadow-sm'
                    : 'text-stone-400 hover:text-stone-200'
                }`}
              >
                Aggressive Scale
              </button>
            </div>

            {/* Download as PDF Button */}
            <button
              onClick={handleDownloadPdfReport}
              disabled={isDownloadingPdf}
              className={`inline-flex items-center gap-2 rounded-xl px-4 py-2.5 text-xs font-bold transition-all shadow-md cursor-pointer ${
                pdfSuccess
                  ? 'bg-emerald-500/20 text-emerald-400 border border-emerald-500/40'
                  : 'bg-bullbee-gradient text-[#171717] hover:brightness-110 disabled:opacity-50'
              }`}
            >
              {isDownloadingPdf ? (
                <>
                  <Loader2 className="h-4 w-4 animate-spin" />
                  <span>Generating PDF...</span>
                </>
              ) : pdfSuccess ? (
                <>
                  <Check className="h-4 w-4 text-emerald-400" />
                  <span>Report Downloaded!</span>
                </>
              ) : (
                <>
                  <FileDown className="h-4 w-4" />
                  <span>Download as PDF</span>
                </>
              )}
            </button>

            <button
              onClick={handleExportSummary}
              className="inline-flex items-center gap-2 rounded-xl border border-stone-700 bg-[#212121] px-4 py-2.5 text-xs font-semibold text-stone-200 hover:border-[#D3AF68]/60 hover:bg-stone-800 transition-colors cursor-pointer"
            >
              <Download className="h-4 w-4 text-[#D3AF68]" />
              <span>Export Raw Data</span>
            </button>
          </div>
        </div>

        {/* 4 Cumulative KPI Cards with increased padding and spacing */}
        <div className="grid grid-cols-2 lg:grid-cols-4 gap-6 mb-12">
          <div className="rounded-2xl border border-stone-800 bg-[#1a1a1a] p-6 sm:p-7 shadow-md">
            <span className="text-xs text-stone-400 uppercase tracking-widest font-display">12-Mo Cumulative Revenue</span>
            <div className="mt-2 flex items-baseline gap-2">
              <span className="font-display text-3xl sm:text-4xl font-bold text-[#D3AF68] font-mono-numbers">
                ${(totalGrossRevenue / 1000000).toFixed(2)}M
              </span>
              <span className="text-xs text-emerald-400 font-semibold font-mono-numbers">
                +{scenario === 'target' ? '661%' : scenario === 'conservative' ? '490%' : '810%'}
              </span>
            </div>
            <p className="mt-2 text-xs text-stone-400">Total gross GMV generated</p>
          </div>

          <div className="rounded-2xl border border-stone-800 bg-[#1a1a1a] p-6 sm:p-7 shadow-md">
            <span className="text-xs text-stone-400 uppercase tracking-widest font-display">Total Ad Capital Invested</span>
            <div className="mt-2 flex items-baseline gap-2">
              <span className="font-display text-3xl sm:text-4xl font-bold text-[#F8F0E2] font-mono-numbers">
                ${(totalSpend / 1000).toFixed(0)}k
              </span>
              <span className="text-xs text-stone-400">Scaled from $21.8k</span>
            </div>
            <p className="mt-2 text-xs text-stone-400">Self-funded from cash flow</p>
          </div>

          <div className="rounded-2xl border border-stone-800 bg-[#1a1a1a] p-6 sm:p-7 shadow-md">
            <span className="text-xs text-stone-400 uppercase tracking-widest font-display">Blended 12-Mo ROAS</span>
            <div className="mt-2 flex items-baseline gap-2">
              <span className="font-display text-3xl sm:text-4xl font-bold text-emerald-400 font-mono-numbers">
                {blendedRoas}x
              </span>
              <span className="text-xs text-stone-400">Gross ROAS</span>
            </div>
            <p className="mt-2 text-xs text-stone-400">Surging via repeat subscriptions</p>
          </div>

          <div className="rounded-2xl border border-stone-800 bg-[#1a1a1a] p-6 sm:p-7 shadow-md">
            <span className="text-xs text-stone-400 uppercase tracking-widest font-display">Month 12 Exit Run Rate</span>
            <div className="mt-2 flex items-baseline gap-2">
              <span className="font-display text-3xl sm:text-4xl font-bold text-[#F8F0E2] font-mono-numbers">
                ${(adjustedData[11].grossRevenue / 1000).toFixed(0)}k/mo
              </span>
              <ArrowUpRight className="h-4 w-4 text-emerald-400" />
            </div>
            <p className="mt-2 text-xs text-stone-400 font-mono-numbers">
              {adjustedData[11].repeatCustomers.toLocaleString()} repeat buyers/mo
            </p>
          </div>
        </div>

        {/* Interactive Growth Trajectory Graph */}
        <div className="rounded-3xl border border-stone-800 bg-[#1a1a1a] p-8 lg:p-12 mb-16 shadow-2xl">
          <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-6 pb-8 border-b border-stone-800">
            <div>
              <div className="flex items-center gap-3">
                <TrendingUp className="h-6 w-6 text-[#D3AF68]" />
                <h3 className="font-display text-2xl font-bold text-[#F8F0E2] uppercase">
                  Monthly Revenue Trajectory & Repeat Cohort Growth
                </h3>
              </div>
              <p className="text-sm text-stone-400 mt-2">
                Hover over data points to inspect monthly unit economics, AOV, and ad spend.
              </p>
            </div>

            {/* Legend */}
            <div className="flex items-center gap-5 text-xs text-stone-400 font-medium">
              <div className="flex items-center gap-2">
                <div className="h-3 w-3 rounded-full bg-[#D3AF68]" />
                <span>Gross Monthly Revenue</span>
              </div>
              <div className="flex items-center gap-2">
                <div className="h-3 w-3 rounded-full bg-sky-400" />
                <span>Ad Spend</span>
              </div>
            </div>
          </div>

          {/* Responsive SVG Chart */}
          <div className="mt-8 relative w-full overflow-hidden">
            <svg
              viewBox={`0 0 ${chartWidth} ${chartHeight}`}
              className="w-full h-64 sm:h-80 overflow-visible"
            >
              <defs>
                <linearGradient id="revenueGradient" x1="0" y1="0" x2="0" y2="1">
                  <stop offset="0%" stopColor="#D3AF68" stopOpacity="0.4" />
                  <stop offset="100%" stopColor="#D3AF68" stopOpacity="0.0" />
                </linearGradient>
              </defs>

              {/* Grid Lines */}
              {[0, 0.25, 0.5, 0.75, 1].map((ratio) => {
                const y = chartHeight - ratio * (chartHeight - 40) - 20;
                return (
                  <line
                    key={ratio}
                    x1="20"
                    y1={y}
                    x2={chartWidth - 20}
                    y2={y}
                    stroke="#2e2e2e"
                    strokeDasharray="4 4"
                    strokeWidth="1"
                  />
                );
              })}

              {/* Area under curve */}
              <path d={areaD} fill="url(#revenueGradient)" />

              {/* Line curve */}
              <path
                d={pathD}
                fill="none"
                stroke="#D3AF68"
                strokeWidth="3.5"
                strokeLinecap="round"
                strokeLinejoin="round"
              />

              {/* Interactive Points */}
              {points.map((p, i) => (
                <g key={i}>
                  <circle
                    cx={p.x}
                    cy={p.y}
                    r={hoveredMonth?.month === p.data.month ? '8' : '5'}
                    className="cursor-pointer fill-[#D3AF68] stroke-[#171717] stroke-2 transition-all duration-150 hover:r-8"
                    onMouseEnter={() => setHoveredMonth(p.data)}
                    onMouseLeave={() => setHoveredMonth(null)}
                  />
                </g>
              ))}
            </svg>

            {/* Hover Tooltip Overlay */}
            {hoveredMonth && (
              <div className="absolute top-4 right-4 rounded-2xl border border-[#D3AF68]/60 bg-[#131313]/95 p-5 shadow-2xl text-xs space-y-2 backdrop-blur-md">
                <span className="font-display font-bold text-[#D3AF68] text-base uppercase block tracking-wider">
                  {hoveredMonth.month} Performance
                </span>
                <div className="flex justify-between gap-6 text-stone-300">
                  <span>Gross Revenue:</span>
                  <span className="font-mono-numbers font-bold text-[#F8F0E2]">
                    ${hoveredMonth.grossRevenue.toLocaleString()}
                  </span>
                </div>
                <div className="flex justify-between gap-6 text-stone-300">
                  <span>Ad Spend:</span>
                  <span className="font-mono-numbers text-stone-400">
                    ${hoveredMonth.spend.toLocaleString()}
                  </span>
                </div>
                <div className="flex justify-between gap-6 text-stone-300">
                  <span>ROAS:</span>
                  <span className="font-mono-numbers font-bold text-emerald-400">
                    {hoveredMonth.roas.toFixed(2)}x
                  </span>
                </div>
                <div className="flex justify-between gap-6 text-stone-300">
                  <span>New / Repeat:</span>
                  <span className="font-mono-numbers text-stone-300">
                    {hoveredMonth.newCustomers.toLocaleString()} / {hoveredMonth.repeatCustomers.toLocaleString()}
                  </span>
                </div>
                <div className="flex justify-between gap-6 text-stone-300">
                  <span>AOV:</span>
                  <span className="font-mono-numbers text-[#D3AF68] font-bold">
                    ${hoveredMonth.aov.toFixed(2)}
                  </span>
                </div>
              </div>
            )}
          </div>
        </div>

        {/* 12-Month Financial Table with spacious padding */}
        <div className="rounded-3xl border border-stone-800 bg-[#1a1a1a] p-8 lg:p-10 shadow-2xl">
          <div className="flex items-center justify-between pb-6 border-b border-stone-800">
            <div>
              <h3 className="font-display text-2xl font-bold text-[#F8F0E2] uppercase">
                Detailed 12-Month Unit Economics Matrix
              </h3>
              <p className="text-xs text-stone-400 mt-0.5">
                All metrics formatted with tabular numerals for precision review
              </p>
            </div>
            <span className="text-xs text-[#D3AF68] font-mono-numbers font-semibold px-3 py-1 bg-[#131313] rounded-lg border border-stone-800">
              Scenario: {scenario.toUpperCase()}
            </span>
          </div>

          <div className="mt-6 overflow-x-auto">
            <table className="w-full text-left text-xs font-mono-numbers">
              <thead>
                <tr className="border-b border-stone-800 text-stone-400 font-display text-[11px] uppercase tracking-wider">
                  <th className="py-3.5 pr-4">Month</th>
                  <th className="py-3.5 px-4">Ad Spend</th>
                  <th className="py-3.5 px-4">Clicks</th>
                  <th className="py-3.5 px-4">Blended CPC</th>
                  <th className="py-3.5 px-4">CVR</th>
                  <th className="py-3.5 px-4">AOV</th>
                  <th className="py-3.5 px-4">New Customers</th>
                  <th className="py-3.5 px-4">Repeat Orders</th>
                  <th className="py-3.5 px-4">Gross Revenue</th>
                  <th className="py-3.5 pl-4 text-right">ROAS</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-stone-800/80">
                {adjustedData.map((row) => (
                  <tr
                    key={row.month}
                    className="hover:bg-[#222222] transition-colors"
                  >
                    <td className="py-4 pr-4 font-display font-bold text-[#F8F0E2] text-sm">
                      {row.month}
                    </td>
                    <td className="py-4 px-4 text-stone-400">
                      ${row.spend.toLocaleString('en-US')}
                    </td>
                    <td className="py-4 px-4 text-stone-300">
                      {row.clicks.toLocaleString('en-US')}
                    </td>
                    <td className="py-4 px-4 text-stone-400">
                      ${row.blendedCpc.toFixed(3)}
                    </td>
                    <td className="py-4 px-4 text-stone-300">
                      {(row.conversionRate * 100).toFixed(2)}%
                    </td>
                    <td className="py-4 px-4 text-[#D3AF68] font-bold">
                      ${row.aov.toFixed(2)}
                    </td>
                    <td className="py-4 px-4 text-stone-300">
                      {row.newCustomers.toLocaleString('en-US')}
                    </td>
                    <td className="py-4 px-4 text-emerald-400 font-semibold">
                      {row.repeatCustomers.toLocaleString('en-US')}
                    </td>
                    <td className="py-4 px-4 font-bold text-[#F8F0E2] text-sm">
                      ${row.grossRevenue.toLocaleString('en-US')}
                    </td>
                    <td className="py-4 pl-4 text-right font-bold text-[#D3AF68] text-sm">
                      {row.roas.toFixed(2)}x
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        </div>
      </div>
    </section>
  );
};
